require 'rspec'

require 'rubame'
